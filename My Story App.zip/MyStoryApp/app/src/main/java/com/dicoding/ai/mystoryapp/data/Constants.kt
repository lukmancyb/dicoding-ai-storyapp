package com.dicoding.ai.mystoryapp.data

object Constants {

    const val USER_PREFERENCES = "user"
}